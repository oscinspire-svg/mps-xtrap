"""
mps_xtrap Licensing
====================
mps_xtrap is released under the Business Source License 1.1 (BUSL-1.1).

  Non-commercial use  — free to use under the terms of the BUSL-1.1.
  Commercial use      — requires a separate commercial license agreement.
  Change Date         — 2029-01-01, after which the code is available under
                        the MIT License.

For commercial licensing, support, or enquiries, contact:
  oscinspire@gmail.com

Sponsorships and donations are welcomed at:
  https://flutterwave.com/pay/6yptuvqab8cu
"""

from __future__ import annotations


# ---------------------------------------------------------------------------
# Box helpers
# ---------------------------------------------------------------------------

def _line(text: str = "", width: int = 64) -> str:
    pad = width - len(text)
    return "║ " + text + " " * max(pad - 1, 0) + "║"

def _sep(width: int = 64) -> str:
    return "╠" + "═" * width + "╣"

def _top(width: int = 64) -> str:
    return "╔" + "═" * width + "╗"

def _bot(width: int = 64) -> str:
    return "╚" + "═" * width + "╝"


W = 64  # inner width

PAYMENT_LINK  = "https://flutterwave.com/pay/6yptuvqab8cu"
SUPPORT_EMAIL = "oscinspire@gmail.com"

# ---------------------------------------------------------------------------
# Licensing notice
# ---------------------------------------------------------------------------

MSG_LICENSE_NOTICE = "\n".join([
    _top(W),
    _line("  mps_xtrap — Licensing", W),
    _sep(W),
    _line("  Released under the Business Source License 1.1 (BUSL-1.1).", W),
    _line("", W),
    _line("  Free to use for non-commercial purposes.", W),
    _line("", W),
    _line("  If you intend to use mps_xtrap for commercial purposes,", W),
    _line("  please reach out to arrange a commercial license:", W),
    _line("  " + SUPPORT_EMAIL, W),
    _sep(W),
    _line("  Sponsorships and donations:", W),
    _line("  " + PAYMENT_LINK, W),
    _bot(W),
])


def show_license() -> None:
    """Print the mps_xtrap licensing notice."""
    print()
    print(MSG_LICENSE_NOTICE)
    print()
